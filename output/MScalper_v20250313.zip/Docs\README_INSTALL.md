﻿# Instrucciones de InstalaciÃ³n de MScalper v20250313

## InstalaciÃ³n Manual en NinjaTrader 8

1. **Abra NinjaTrader 8**
2. Vaya a **Tools > Import > NinjaScript Add-On...**
3. Seleccione los archivos .cs de la carpeta Source de este paquete
4. En el cuadro de diÃ¡logo de importaciÃ³n, haga clic en **OK**
5. Copie los archivos de configuraciÃ³n de la carpeta Config a:
   * {Documentos}\NinjaTrader 8\bin\Custom\config\
6. Reinicie NinjaTrader para completar la instalaciÃ³n

## ConfiguraciÃ³n

Consulte los archivos en la carpeta Docs para obtener informaciÃ³n detallada sobre la configuraciÃ³n y uso.

## Soporte

Para soporte tÃ©cnico, contacte a jvlora@hublai.com
